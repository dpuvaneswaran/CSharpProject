﻿using System;
using System.Collections.Generic;

namespace HomePageProject
{
    public partial class Highscores
    {
        public int HighscoreId { get; set; }
        public string Username { get; set; }
        public int? Score { get; set; }
    }
}
