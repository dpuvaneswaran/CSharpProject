﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace HomePageProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            

            // Logins Input Fields
            string username = UsernameTxt.Text;
            string password = PasswordTxt.Password;

            ErrorMessageTxt.Text = "";

            //Setting the SQL Credentials
            SqlConnection conn = new SqlConnection("Data Source = localhost;" + "Initial Catalog = Project;" + "User ID = SA;" + "Password= Passw0rd2018;");

            conn.Open();

            //Using Data Manipulative Language to Query
            SqlCommand command = new SqlCommand("SELECT * " + "FROM AppUsers WHERE username ='" + username + "'  and password ='" + password + "'", conn);

            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet dSet = new DataSet();
            adapter.Fill(dSet);
            if (dSet.Tables[0].Rows.Count > 0)
            {
                this.Hide();
                LogIn login = new LogIn();
                login.Show();
                Close();
            }
            else
            {
                ErrorMessageTxt.Text = "Try Again Incorrect";
            }
            conn.Close();

        }








    }
}
