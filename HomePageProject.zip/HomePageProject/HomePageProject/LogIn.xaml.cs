﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomePageProject
{
    /// <summary>
    /// Interaction logic for LogIn.xaml
    /// </summary>
    public partial class LogIn : Window
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void Startbtn_Click(object sender, RoutedEventArgs e)
        {
            TicTacToe tic = new TicTacToe();
            tic.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Instructions ins = new Instructions();
            ins.Show();
        }


        private void HighscoreClick_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Highscores high = new Highscores();
            high.Show();

        }
    }
}
