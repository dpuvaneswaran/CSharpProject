﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomePageProject
{

    //Types of values in the game
    public enum MarkType
    {
        Nought,
        Cross,
        Free
    }
}
