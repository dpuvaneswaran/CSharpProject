﻿using System;
using System.Collections.Generic;

namespace HomePageProject
{
    public partial class AppUsers
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public int? Password { get; set; }
    }
}
